Heavy Unit (Kaneko / Taito, 1988) for MiSTer - v1.0

Unpack onto the SD card root (the folders are already in the MiSTer layout):

  _Arcade/cores/heavyunit_20261017.rbf     the core
  _Arcade/*.mra                            the five sets (World, Japan x3, US)

You also need the ROM set, which is not part of this release:

  games/mame/hvyunit.zip                   MAME 0.289, merged set (the clones use it as their parent)

The MRAs use the fast-load path (address="0x32000000"): a recent Main_MiSTer loads the game in about a second,
an older one loads at the old speed.

OSD: Aspect ratio, Scale, Scandoubler Fx, Video timing (TV 58.3 Hz default / MAME 58.0 Hz), CRT Adjust
(H-Size, H-Position, V-Shift), DIP switches, SDRAM read capture, Reset.
Controls: joystick + Fire / Bomb / Start 1P / Start 2P / Coin; keyboard 1, 2 start, 5, 6 coin, F2 service.

RetroTINK 4K on HDMI direct video: with the default TV timing the RT4K shows 'MiSTer 240p' (System Status
page 1, 'Detected Mode') and does not squash the picture while the MiSTer OSD is open. The MAME timing setting
has not been tried on an RT4K. If an RT4K ever squashes the picture, this stops the MiSTer sending its
'menu present' flag, per core, in MiSTer.ini:

    [hvyunit]
    spd_quirk=2

See RELEASE_NOTES.md for what was checked and the known limits. GPL-3.0, see LICENSE; the sources are in heavyunit_build4_src.zip of the repository.
